<?php
require 'db.php';
session_start();

// Luăm ID-ul din link (ex: descriere.php?id=5)
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Căutăm produsul
$stmt = $pdo->prepare("SELECT * FROM produse WHERE id = ?");
$stmt->execute([$id]);
$produs = $stmt->fetch();

if (!$produs) {
    die("Produsul nu a fost găsit.");
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Descriere - <?php echo htmlspecialchars($produs['nume']); ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="layout">
    <header><h1>Mobila Elegantă</h1></header>
    
    <nav>
        <a href="produse.php">⬅ Înapoi la Produse</a>
    </nav>

    <main>
        <div class="container-descriere" style="display: flex; gap: 30px; padding: 20px;">
            <div class="foto">
                <img src="imagine/<?php echo $produs['imagine']; ?>" style="max-width: 400px; border-radius: 8px;">
            </div>
            
            <div class="detalii">
                <h2><?php echo htmlspecialchars($produs['nume']); ?></h2>
                <p style="font-size: 1.5rem; color: #4e342e; font-weight: bold;"><?php echo $produs['pret']; ?> lei</p>
                
                <div class="text-descriere" style="margin-top: 20px; line-height: 1.6; white-space: pre-line;">
                    <h3>Descrierea produsului:</h3>
                    <p><?php echo nl2br(htmlspecialchars($produs['descriere'])); ?></p>
                </div>

                <button class="adauga-cos" 
                        data-id="<?php echo $produs['id']; ?>" 
                        data-name="<?php echo $produs['nume']; ?>" 
                        data-price="<?php echo $produs['pret']; ?>"
                        style="margin-top: 20px; padding: 10px 20px; background: #4e342e; color: white; border: none; cursor: pointer;">
                    Adaugă în coș
                </button>
            </div>
        </div>
    </main>
</body>
</html>