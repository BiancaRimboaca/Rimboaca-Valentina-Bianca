<?php
require 'db.php';
session_start();

// 1. Verificăm dacă utilizatorul este logat
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];
// Preluăm email-ul din sesiune pentru a găsi mesajele în tabelul 'contact'
$email_client = $_SESSION['email'] ?? ''; 

// 2. Preluăm COMENZILE (Folosim user_id - așa cum e în tabelul tău 'comenzi')
$stmtComenzi = $pdo->prepare("SELECT * FROM comenzi WHERE user_id = ? ORDER BY data_comanda DESC");
$stmtComenzi->execute([$user_id]);
$comenzi = $stmtComenzi->fetchAll();

// 3. Preluăm MESAJELE (Folosim email - așa cum e în tabelul tău 'contact')
// Luăm toate mesajele trimise de acest email, indiferent dacă au răspuns sau nu
$stmtMesaje = $pdo->prepare("SELECT * FROM contact WHERE email = ? ORDER BY data_trimitere DESC");
$stmtMesaje->execute([$email_client]);
$mesaje_contact = $stmtMesaje->fetchAll();
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Profilul Meu - Mobila Elegantă</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
    <style>
        /* Stiluri pentru a separa frumos secțiunile */
        .sectiune-profil { background: white; padding: 20px; border-radius: 8px; margin-bottom: 30px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h3 { border-bottom: 2px solid #4e342e; padding-bottom: 10px; color: #4e342e; }
        
        .tabel-comenzi { width: 100%; border-collapse: collapse; margin-top: 15px; }
        .tabel-comenzi th, .tabel-comenzi td { border: 1px solid #ddd; padding: 12px; text-align: center; }
        .tabel-comenzi th { background: #4e342e; color: white; }

        .card-suport { background: #fdf5e6; border-left: 5px solid #4e342e; padding: 15px; margin-top: 15px; border-radius: 4px; }
        .raspuns-admin { background: white; border: 1px solid #deb887; padding: 10px; margin-top: 10px; border-radius: 4px; }
        .status-badge { font-weight: bold; padding: 4px 8px; border-radius: 4px; font-size: 0.9em; }
    </style>
</head>
<body class="layout">
    <header><h1>Mobila Elegantă - Profil Client</h1></header>

    <nav>
        <a href="index.php">Acasă</a>
        <a href="produse.php">Produse</a>
        <a href="contact.php">Contact</a>
        <a href="logout.php">Logout</a>
    </nav>

    <main>
        <h2>Salut, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h2>

        <section class="sectiune-profil">
            <h3>🛒 Comenzile mele</h3>
            <?php if (empty($comenzi)): ?>
                <p>Nu ai nicio comandă înregistrată încă.</p>
            <?php else: ?>
                <table class="tabel-comenzi">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Data</th>
                            <th>Suma Totală</th>
                            <th>Status Livrare</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($comenzi as $c): ?>
                        <tr>
                            <td>#<?php echo $c['id']; ?></td>
                            <td><?php echo date('d.m.Y', strtotime($c['data_comanda'])); ?></td>
                            <td><?php echo $c['total_plata']; ?> lei</td>
                            <td><span class="status-badge"><?php echo htmlspecialchars($c['status']); ?></span></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </section>

        <section class="sectiune-profil">
            <h3>📬 Mesaje trimise către Suport</h3>
            <?php if (empty($mesaje_contact)): ?>
                <p>Nu ai trimis niciun mesaj prin formularul de contact (Email verificat: <?php echo htmlspecialchars($email_client); ?>).</p>
            <?php else: ?>
                <?php foreach ($mesaje_contact as $m): ?>
                    <div class="card-suport">
                        <p><strong>Subiect:</strong> <?php echo htmlspecialchars($m['subiect']); ?></p>
                        <p><strong>Mesajul tău:</strong> <em>"<?php echo htmlspecialchars($m['mesaj']); ?>"</em></p>
                        <small style="color: #666;">Data trimiterii: <?php echo $m['data_trimitere']; ?></small>

                        <div class="raspuns-admin">
                            <strong style="color: #2e7d32;">Răspuns Administrator:</strong>
                            <p>
                                <?php 
                                    if (!empty($m['mesaj_admin'])) {
                                        echo nl2br(htmlspecialchars($m['mesaj_admin']));
                                    } else {
                                        echo "<span style='color: #888;'>Încă nu ai primit un răspuns. Admin-ul va analiza solicitarea ta în cel mai scurt timp.</span>";
                                    }
                                ?>
                            </p>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </section>
    </main>

    <footer><p>&copy; 2026 Mobila Elegantă</p></footer>
</body>
</html>