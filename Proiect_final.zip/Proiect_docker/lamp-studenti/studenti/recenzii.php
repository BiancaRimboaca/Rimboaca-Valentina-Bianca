<?php
require 'db.php';
session_start();

$mesaj_status = "";
$tip_alert = ""; // succes sau eroare

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['trimite_recenzie'])) {
    $nume = trim($_POST['nume']);
    $mesaj = trim($_POST['mesaj']);
    $rating = (int)$_POST['stele'];

    try {
        $stmt = $pdo->prepare("INSERT INTO recenzii (nume_utilizator, comentariu, rating, status) VALUES (?, ?, ?, 'in_asteptare')");
        if ($stmt->execute([$nume, $mesaj, $rating])) {
            $mesaj_status = "Recenzia a fost trimisă! Va apărea pe site după aprobare.";
            $tip_alert = "alert-success";
        }
    } catch (PDOException $e) {
        $mesaj_status = "Eroare la trimitere. Te rugăm să încerci mai târziu.";
        $tip_alert = "alert-error";
    }
}

$stmt = $pdo->query("SELECT * FROM recenzii WHERE status = 'aprobata' ORDER BY data_postare DESC");
$recenzii_aprobate = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Recenzii - Mobila Elegantă</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
</head>
<body class="layout">
    <header><h1>Mobila Elegantă</h1></header>
    
    <nav>
        <a href="index.php">Acasă</a>
        <a href="produse.php">Produse</a>
        <a href="despre.php">Despre noi</a>
        <a href="recenzii.php" class="active">Recenzii</a>
        <a href="contact.php">Contact</a>
        <a href="cos.php">Coș(<span id="cart-count">0</span>)</a>
        
        <?php if(isset($_SESSION['rol']) && $_SESSION['rol'] === 'admin'): ?>
            <a href="admin.php" style="background: #ffcc80; color: #333; font-weight: bold; padding: 5px 10px; border-radius: 4px;">🛠️ PANOU ADMIN</a>
        <?php endif; ?>

        <?php if(isset($_SESSION['username'])): ?>
            <a href="profil.php" style="color: #ffcc80;">Salut, <?php echo htmlspecialchars($_SESSION['username']); ?>!</a>
            <a href="logout.php">Logout</a>
        <?php else: ?>
            <a href="login.php">Login</a>
        <?php endif; ?>

    </nav>

    <aside>
        <h3>Părerea ta contează</h3>
        <p>Clienții noștri sunt inima afacerii. Lasă-ne un feedback pentru a ne ajuta să creștem!</p>
    </aside>

    <main>
        <div class="container-recenzii">
            <h2>Ce spun clienții noștri</h2>

            <?php if($mesaj_status): ?>
                <div class="alert <?php echo $tip_alert; ?>">
                    <?php echo $mesaj_status; ?>
                </div>
            <?php endif; ?>

            <div class="recenzii-grid">
                <?php if(empty($recenzii_aprobate)): ?>
                    <p>Încă nu sunt recenzii publicate. Fii primul care ne scrie!</p>
                <?php endif; ?>

                <?php foreach ($recenzii_aprobate as $r): ?>
                    <article class="card-recenzie">
                        <div class="stele">
                            <?php for($i=1; $i<=5; $i++) echo ($i <= $r['rating']) ? "★" : "☆"; ?>
                        </div>
                        <p class="text-recenzie">"<?php echo htmlspecialchars($r['comentariu']); ?>"</p>
                        <h4 class="autor">— <?php echo htmlspecialchars($r['nume_utilizator']); ?></h4>
                        <small class="data"><?php echo date("d.m.Y", strtotime($r['data_postare'])); ?></small>
                    </article>
                <?php endforeach; ?>
            </div>

            <hr class="separator">

            <section class="form-recenzie">
                <h3>Adaugă recenzia ta</h3>
                <form action="recenzii.php" method="POST" class="form-elegant">
                    <div class="grup-input">
                        <label>Numele tău:</label>
                        <input type="text" name="nume" value="<?php echo $_SESSION['username'] ?? ''; ?>" required placeholder="Ex: Popescu Ion">
                    </div>

                    <div class="grup-input">
                        <label>Mesajul tău:</label>
                        <textarea name="mesaj" rows="4" required placeholder="Spune-ne părerea ta..."></textarea>
                    </div>

                    <div class="grup-input">
                        <label>Rating:</label>
                        <select name="stele" required>
                            <option value="5">★★★★★ - Excelent</option>
                            <option value="4">★★★★☆ - Foarte Bun</option>
                            <option value="3">★★★☆☆ - Bun</option>
                            <option value="2">★★☆☆☆ - Satisfăcător</option>
                            <option value="1">★☆☆☆☆ - Slab</option>
                        </select>
                    </div>

                    <button type="submit" name="trimite_recenzie" class="btn-trimite">Trimite Recenzia</button>
                </form>
            </section>
        </div>
    </main>

    <footer><p>&copy; 2026 Mobila Elegantă</p></footer>
</body>
</html>