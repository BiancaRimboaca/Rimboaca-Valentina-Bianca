<?php
require 'db.php';
session_start();

// Verificăm dacă ești admin
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Salvarea răspunsului tău (Update în tabelul contact)
if (isset($_POST['raspunde_admin'])) {
    $id_mesaj = $_POST['id_mesaj'];
    $raspuns = $_POST['text_raspuns'];

    $stmt = $pdo->prepare("UPDATE contact SET mesaj_admin = ? WHERE id = ?");
    $stmt->execute([$raspuns, $id_mesaj]);
    echo "<script>alert('Răspuns salvat!'); window.location.href='admin_mesaje.php';</script>";
}

// Luăm toate mesajele, cele mai noi primele
$mesaje = $pdo->query("SELECT * FROM contact ORDER BY data_trimitere DESC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Admin - Mesaje</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="layout">
    <header><h1>Inbox Mesaje (Admin)</h1></header>
    <nav><a href="admin.php">⬅ Dashboard</a></nav>
    <main>
        <?php foreach ($mesaje as $m): ?>
            <div style="border: 2px solid #4e342e; padding: 15px; margin-bottom: 20px; background: #fff;">
                <p><strong>De la:</strong> <?php echo htmlspecialchars($m['nume']); ?> (<?php echo $m['email']; ?>)</p>
                <p><strong>Subiect:</strong> <?php echo htmlspecialchars($m['subiect']); ?></p>
                <p><strong>Mesaj:</strong> <?php echo nl2br(htmlspecialchars($m['mesaj'])); ?></p>
                <p><small>Primit la: <?php echo $m['data_trimitere']; ?></small></p>
                
                <hr>
                
                <form method="POST">
                    <input type="hidden" name="id_mesaj" value="<?php echo $m['id']; ?>">
                    <label><strong>Răspunsul tău (va apărea la client în profil):</strong></label><br>
                    <textarea name="text_raspuns" style="width: 100%;" rows="3"><?php echo htmlspecialchars($m['mesaj_admin'] ?? ''); ?></textarea>
                    <button type="submit" name="raspunde_admin" style="margin-top: 10px; padding: 5px 15px; background: #2e7d32; color: white; border: none; cursor: pointer;">
                        Salvează / Trimite Răspuns
                    </button>
                </form>
            </div>
        <?php endforeach; ?>
    </main>
</body>
</html>