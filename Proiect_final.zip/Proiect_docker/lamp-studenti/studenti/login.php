<?php
require 'db.php'; // Conexiunea la baza de date
session_start();

$mesaj = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password_introdusa = trim($_POST['password']);

    try {
        // 1. MODIFICARE: Am adăugat 'email' în SELECT
        $stmt = $pdo->prepare("SELECT id, username, password, email, rol FROM utilizatori WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password_introdusa, $user['password'])) {
            
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['rol'] = $user['rol'];

            // 2. MODIFICARE: Salvăm email-ul în sesiune (Esențial pentru profil.php!)
            $_SESSION['email'] = $user['email']; 

            if ($_SESSION['rol'] === 'admin') {
                header("Location: admin.php");
            } else {
                header("Location: produse.php");
            }
            exit;
            
        } else {
            $mesaj = "Nume de utilizator sau parolă incorectă!";
        }
    } catch (PDOException $e) {
        $mesaj = "Eroare la baza de date: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Mobila Elegantă</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
</head>
<body class="layout">

    <header>
        <h1>Mobila Elegantă</h1>
    </header>

    <nav>
        <a href="index.php">Acasă</a>
        <a href="register.php">Înregistrare</a>
    </nav>

    <aside>
        <h3>Autentificare</h3>
        <p>Introdu datele tale pentru a accesa contul.</p>
    </aside>

    <main>
        <div style="max-width: 400px; margin: 2rem auto; background: white; padding: 2rem; border-radius: 10px; box-shadow: 0 4px 15px rgba(0,0,0,0.1);">
            <h2 style="text-align: center; color: #4e342e;">Intră în cont</h2>

            <?php if($mesaj): ?>
                <div style="background: #ffebee; color: #c62828; padding: 10px; border-radius: 5px; margin-bottom: 1.5rem; text-align: center; font-weight: bold;">
                    ⚠️ <?php echo $mesaj; ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="login.php" style="display: flex; flex-direction: column; gap: 1.2rem;">
                <div>
                    <label for="username" style="display: block; margin-bottom: 5px; font-weight: bold;">Utilizator:</label>
                    <input type="text" id="username" name="username" required 
                           style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 5px;">
                </div>

                <div>
                    <label for="password" style="display: block; margin-bottom: 5px; font-weight: bold;">Parolă:</label>
                    <input type="password" id="password" name="password" required 
                           style="width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 5px;">
                </div>

                <button type="submit" style="background: #4e342e; color: white; padding: 12px; border: none; border-radius: 5px; cursor: pointer; font-size: 1.1rem; font-weight: bold;">
                    Autentificare
                </button>
            </form>

            <p style="margin-top: 1.5rem; text-align: center;">
                Nu ai cont? <a href="register.php" style="color: #4e342e; font-weight: bold;">Înregistrează-te aici</a>
            </p>
        </div>
    </main>

    <footer>
        <p>&copy; 2026 Mobila Elegantă. Secțiune Securizată.</p>
    </footer>

</body>
</html>