<?php
session_start();
?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Mobila Elegantă - mobilier modern din lemn masiv.">
    <title>Mobila Elegantă - Acasă</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
</head>
<body class="layout" id="top"> <header>
        <h1>Mobila Elegantă</h1>
    </header>

    <nav>
        <a href="index.php" class="active">Acasă</a>
        <a href="produse.php">Produse</a>
        <a href="despre.php">Despre noi</a>
        <a href="recenzii.php">Recenzii</a>
        <a href="contact.php">Contact</a>
        <a href="cos.php">Coș(<span id="cart-count">0</span>)</a>

        <?php if(isset($_SESSION['rol']) && $_SESSION['rol'] === 'admin'): ?>
            <a href="admin.php" style="background: #ffcc80; color: #333; font-weight: bold; padding: 5px 10px; border-radius: 4px;">🛠️ PANOU ADMIN</a>
        <?php endif; ?>

        <?php if(isset($_SESSION['username'])): ?>
            <a href="profil.php" style="color: #ffcc80;">Salut, <?php echo htmlspecialchars($_SESSION['username']); ?>!</a>
            <a href="logout.php">Logout</a>
        <?php else: ?>
            <a href="login.php">Login</a>
        <?php endif; ?>
    </nav>

    <aside>
        <h3>Noutăți</h3>
        <p>Noua colecție de vară a sosit! Reduceri de până la 20% la seturile de living.</p>
        <hr style="margin: 15px 0; border: 0; border-top: 1px solid #ddd;">
        <h3>Program Showroom</h3>
        <p>Luni - Vineri: 09:00 - 18:00</p>
        <p>Sâmbătă: 10:00 - 14:00</p>
    </aside>

    <main class="acasa">
        <section style="display: flex; flex-direction: column; align-items: center; text-align: center;">
            <h2 style="margin-bottom: 1.5rem;">Bun venit la Mobila Elegantă</h2>
            <p style="max-width: 1700px; margin-bottom: 2rem; font-size: 1.1rem;">
                Transformă-ți casa într-un sanctuar al eleganței. Folosim doar lemn masiv de cea mai bună calitate și finisaje premium pentru a crea piese de mobilier care durează o viață.
            </p>
            
            <img src="imagine-living.jfif" alt="Living modern" 
                 style="max-width: 100%; height: auto; border-radius: 5px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); margin: auto;">
            
            <div style="margin-top: 2rem;">
              <a href="produse.php" style="background:#4e342e; color:white; text-decoration: none; padding: 15px 30px; border-radius:5px; font-weight:bold;">
                Vezi Catalogul Complet
              </a>
            </div>
        </section>
    </main>

    <footer>
        <p>&copy; 2026 Mobila Elegantă. Toate drepturile rezervate.</p>
    </footer>
    
    <a href="#top" class="to-top" id="backToTop">⬆️</a>
    <script src="script.js?v=<?php echo time(); ?>"></script>

</body>
</html>