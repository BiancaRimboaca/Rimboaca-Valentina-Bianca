<?php
require 'db.php';
session_start();
// Nu uita să ai fișierul db.php în același folder pentru conexiunea la baza de date
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact - Mobila Elegantă</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
</head>

<body class="layout" id="top"> <header>
        <h1>Mobila Elegantă</h1>
    </header>

    <nav>
        <a href="index.php">Acasă</a>
        <a href="produse.php">Produse</a>
        <a href="despre.php">Despre noi</a>
        <a href="recenzii.php"> Recenzii</a>
        <a href="contact.php" class="active">Contact</a>
        <a href="cos.php">Coș(<span id="cart-count">0</span>)</a>

        <?php if(isset($_SESSION['rol']) && $_SESSION['rol'] === 'admin'): ?>
            <a href="admin.php" style="background: #ffcc80; color: #333; font-weight: bold; padding: 5px 10px; border-radius: 4px;">🛠️ PANOU ADMIN</a>
        <?php endif; ?>

        <?php if(isset($_SESSION['username'])): ?>
            <a href="profil.php" style="color: #ffcc80;">Salut, <?php echo htmlspecialchars($_SESSION['username']); ?>!</a>
            <a href="logout.php">Logout</a>
        <?php else: ?>
            <a href="login.php">Login</a>
        <?php endif; ?>

    </nav>

    <aside>
        <h3>Informații Contact</h3>
        <p>📍 <strong>Adresă:</strong> Str. X nr. X, Roșiori de Vede</p>
        <p>📞 <strong>Telefon:</strong> 0770 403 317</p>
        <p>📧 <strong>Email:</strong> contact@mobiladelux.ro</p>
        
        <hr style="margin: 20px 0; border: 0; border-top: 1px solid #d7ccc8;">
        
        <h3>Program Showroom</h3>
        <ul style="list-style: none; padding: 0;">
            <li>Luni - Vineri: 09:00 - 18:00</li>
            <li>Sâmbătă: 10:00 - 14:00</li>
            <li>Duminică: Închis</li>
        </ul>
    </aside>

    <main>
        <h2>Trimite-ne un mesaj</h2>
        <p>Dacă ai întrebări despre produsele noastre sau dorești o comandă personalizată, completează formularul de mai jos.</p>

        <div class="form-group">
            <div class="input-control">
                <label for="nume">Nume complet:</label>
                <input type="text" id="nume" name="nume">
            </div>

            <div class="input-control">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email">
            </div>

            <div class="input-control">
                <label for="telefon">Telefon (opțional):</label>

                <input type="tel" id="telefon" name="telefon" placeholder="07xxxxxxxx">
            </div>

            <div class="input-control">
                <label for="subiect">Subiect:</label>

                <input type="text" id="subiect" name="subiect" required placeholder="Despre ce este vorba?">

            </div>

            <div class="input-control">
                <label for="mesaj">Mesajul tău:</label>
                <textarea id="mesaj" name="mesaj" rows="5" required placeholder="Scrie aici întrebarea ta..."></textarea>
            </div>

            <div class="input-control"> <button type="submit" class="btn-trimite">Trimite Mesajul</button>
            </div>

        </div>

            <section class="input-control">
                <h3>Locația noastră</h3>
                    <div class="map-wrapper">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d89053.16257986466!2d24.906346580454276!3d44.10438018799602!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40adae333b1c48c9%3A0x2d41960bcd4c6c2e!2s145100%20Ro%C8%99iori%20de%20Vede!5e1!3m2!1sro!2sro!4v1768771411292!5m2!1sro!2sro" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade">
                    </div>        
                        </iframe>
            </section>

    </main>

    <footer>
        <p>&copy; 2026 Mobila Elegantă. Toate drepturile rezervate.</p>
    </footer>

    <a href="#top" class="to-top" id="backToTop">⬆️</a>

    <script src="script.js?v=<?php echo time(); ?>"></script>
</body>
</html>