<?php
require 'db.php';
session_start();
if ($_SESSION['rol'] !== 'admin') { header("Location: login.php"); exit; }

// Aprobare Recenzie
if (isset($_GET['aproba'])) {
    $stmt = $pdo->prepare("UPDATE recenzii SET status = 'aprobata' WHERE id = ?");
    $stmt->execute([$_GET['aproba']]);
}

$recenzii = $pdo->query("SELECT * FROM recenzii WHERE status = 'in_asteptare'")->fetchAll();
?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Admin - Recenzii</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="layout">
    <header><h1>Moderare Recenzii noi</h1></header>
    <main>
        <?php foreach($recenzii as $r): ?>
            <div style="background: #f9f9f9; padding: 15px; margin-bottom: 10px; border-left: 5px solid orange;">
                <strong><?php echo $r['nume_utilizator']; ?>:</strong>
                <p><?php echo $r['comentariu']; ?></p>
                <a href="?aproba=<?php echo $r['id']; ?>" style="color: green; font-weight: bold;">✅ APROBĂ</a>
            </div>
        <?php endforeach; ?>
        <?php if(empty($recenzii)) echo "<p>Nu sunt recenzii noi de verificat.</p>"; ?>
    </main>
</body>
</html>