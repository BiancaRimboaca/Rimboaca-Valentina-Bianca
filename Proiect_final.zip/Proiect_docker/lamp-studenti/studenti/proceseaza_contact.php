<?php
require 'db.php'; // Verifică dacă ai fișierul db.php corect

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Luăm datele din formular
    $nume = $_POST['nume'] ?? '';
    $email = $_POST['email'] ?? '';
    $telefon = $_POST['telefon'] ?? '';
    $subiect = $_POST['subiect'] ?? '';
    $mesaj = $_POST['mesaj'] ?? '';

    try {
        // Pregătim comanda SQL
        $sql = "INSERT INTO contact (nume, email, telefon, subiect, mesaj) VALUES (?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($sql);
        
        // Executăm și trimitem datele
        if ($stmt->execute([$nume, $email, $telefon, $subiect, $mesaj])) {
            // Dacă a mers, afișăm un mesaj și ne întoarcem la pagina de contact
            echo "<script>
                    alert('Mesaj trimis cu succes! Te vom contacta în curând.');
                    window.location.href='contact.php';
                  </script>";
        }
    } catch (PDOException $e) {
        // Dacă apare o eroare de SQL, o afișăm ca să știm ce să reparăm
        die("Eroare la salvarea în baza de date: " . $e->getMessage());
    }
} else {
    // Dacă cineva încearcă să acceseze fișierul direct, îl trimitem înapoi
    header("Location: contact.php");
    exit;
}
?>