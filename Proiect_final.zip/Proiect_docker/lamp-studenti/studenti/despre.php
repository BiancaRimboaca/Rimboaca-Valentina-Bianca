<?php
session_start();
?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Mobila Elegantă - mobilier modern din lemn masiv.">
    <title>Mobila Elegantă - Despre noi</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
</head>
<body class="layout" id="top"> <header>
        <h1>Mobila Elegantă</h1>
    </header>

    <nav>
        <a href="index.php">Acasă</a>
        <a href="produse.php">Produse</a>
        <a href="despre.php" class="active">Despre noi</a>
        <a href="recenzii.php"> Recenzii</a>
        <a href="contact.php"> Contact</a>
        <a href="cos.php">Coș(<span id="cart-count">0</span>)</a>



        <<?php if(isset($_SESSION['rol']) && $_SESSION['rol'] === 'admin'): ?>
            <a href="admin.php" style="background: #ffcc80; color: #333; font-weight: bold; padding: 5px 10px; border-radius: 4px;">🛠️ PANOU ADMIN</a>
        <?php endif; ?>

        <?php if(isset($_SESSION['username'])): ?>
            <a href="profil.php" style="color: #ffcc80;">Salut, <?php echo htmlspecialchars($_SESSION['username']); ?>!</a>
            <a href="logout.php">Logout</a>
        <?php else: ?>
            <a href="login.php">Login</a>
        <?php endif; ?>

    </nav>

    <aside>
        <h3>Valorile noastre</h3>
        <ul style="list-style: none; padding: 0;">
            <li style="margin-bottom: 10px;">🌲 <strong>Calitate:</strong> Lemn masiv selecționat.</li>
            <li style="margin-bottom: 10px;">✍️ <strong>Design:</strong> Piese unice, realizate manual.</li>
            <li style="margin-bottom: 10px;">🤝 <strong>Respect:</strong> Garanție și suport pentru clienți.</li>
        </ul>
        <hr style="margin: 20px 0; border: 0; border-top: 1px solid #ddd;">
        <h3>Unde ne găsești?</h3>
        <p>Showroom București, Str. Lemnului Nr. 10</p>
    </aside>

    <main class="despre">
        <h2>Povestea Noastră</h2>
        <div style="line-height: 1.8;">
            <p>Suntem o echipă pasionată de design interior și de prelucrarea lemnului. Cu peste 10 ani de experiență, creăm mobilier care îmbină eleganța, confortul și durabilitatea.</p>
            
            <p>Fiecare piesă este realizată manual, din materiale naturale, atent selecționate, pentru a aduce un plus de stil oricărei locuințe. Credem că mobila nu este doar un obiect utilitar, ci o parte din sufletul unei case.</p>
            
            <div style="margin-top: 2rem; display: flex; gap: 20px; flex-wrap: wrap;">
                <img src="https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&w=400&q=80" alt="Atelier mobila" style="flex: 1; min-width: 250px; border-radius: 8px; max-width: 100%; height: auto;">
                <div style="flex: 1; min-width: 250px;">
                    <h3>De ce noi?</h3>
                    <p>Spre deosebire de producția de serie, noi ne concentrăm pe detalii. Folosim tehnici tradiționale de îmbinare a lemnului, asigurând astfel o rezistență de zeci de ani pentru fiecare produs care iese din atelierul nostru.</p>
                </div>
            </div>
        </div>
    </main>

    <footer>
        <p>&copy; 2026 Mobila Elegantă. Toate drepturile rezervate.</p>
    </footer>

    <a href="#top" class="to-top" id="backToTop">⬆️ Top</a>

    <script src="script.js?v=<?php echo time(); ?>"></script>
</body>
</html>
