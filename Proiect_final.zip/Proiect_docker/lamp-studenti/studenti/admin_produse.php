<?php
require 'db.php';
session_start();
if ($_SESSION['rol'] !== 'admin') { header("Location: login.php"); exit; }

// Adăugare Produs
if (isset($_POST['adauga_produs'])) {
    $stmt = $pdo->prepare("INSERT INTO produse (nume, pret, imagine, categorie) VALUES (?, ?, ?, ?)");
    $stmt->execute([$_POST['nume'], $_POST['pret'], $_POST['imagine'], $_POST['categorie']]);
}

// Ștergere Produs
if (isset($_GET['sterge'])) {
    $stmt = $pdo->prepare("DELETE FROM produse WHERE id = ?");
    $stmt->execute([$_GET['sterge']]);
    header("Location: admin_produse.php");
}

$produse = $pdo->query("SELECT * FROM produse")->fetchAll();
?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Admin - Catalog</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="layout">
    <header><h1>Catalog Produse</h1></header>
    <main>
        <h3>Adaugă Produs Nou</h3>
        <form method="POST">
            <input type="text" name="nume" placeholder="Nume" required>
            <input type="number" name="pret" placeholder="Pret" required>
            <input type="text" name="imagine" placeholder="imagine.jpg" required>
            <select name="categorie">
                <option value="Living">Living</option>
                <option value="Dormitor">Dormitor</option>
            </select>
            <button type="submit" name="adauga_produs">Salvează</button>
        </form>

        <h3>Produse Active</h3>
        <div style="display: flex; flex-wrap: wrap; gap: 10px;">
            <?php foreach($produse as $p): ?>
                <div style="border: 1px solid #ccc; padding: 10px;">
                    <p><?php echo $p['nume']; ?> - <?php echo $p['pret']; ?> lei</p>
                    <a href="?sterge=<?php echo $p['id']; ?>" style="color:red;">Șterge</a>
                </div>
            <?php endforeach; ?>
        </div>
    </main>
</body>
</html>