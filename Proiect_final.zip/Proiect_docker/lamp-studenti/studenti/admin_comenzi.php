<?php
// 1. Activăm erorile pentru a vedea ce nu merge
error_reporting(E_ALL);
ini_set('display_errors', 1);

require 'db.php';
session_start();

// 2. Verificăm dacă ești Admin
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'admin') {
    die("Acces refuzat! Nu ai drepturi de administrator.");
}

// 3. Logica de actualizare a statusului
if (isset($_POST['update_status'])) {
    $id_comanda = $_POST['comanda_id'];
    $status_nou = $_POST['noul_status'];
    
    $stmt = $pdo->prepare("UPDATE comenzi SET status = ? WHERE id = ?");
    $stmt->execute([$status_nou, $id_comanda]);
    header("Location: admin_comenzi.php?succes=1");
    exit;
}

// 4. Luăm toate comenzile din baza de date
try {
    $stmt = $pdo->query("SELECT * FROM comenzi ORDER BY data_comanda DESC");
    $comenzi = $stmt->fetchAll();
} catch (PDOException $e) {
    die("Eroare la citirea comenzilor: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <title>Gestionare Comenzi - Admin</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
</head>
<body class="layout">
    <header><h1>Gestionare Comenzi</h1></header>
    
    <nav>
        <a href="admin.php">⬅ Înapoi la Dashboard</a>
        <a href="index.php">Vezi Site</a>
    </nav>

    <main>
        <h2>Lista Comenzilor Primite</h2>
        
        <?php if(isset($_GET['succes'])): ?>
            <p style="color: green; font-weight: bold;">✅ Statusul a fost actualizat cu succes!</p>
        <?php endif; ?>

        <table border="1" style="width: 100%; border-collapse: collapse; margin-top: 20px; background: white;">
            <thead>
                <tr style="background: #4e342e; color: white;">
                    <th style="padding: 10px;">ID</th>
                    <th>Client</th>
                    <th>Total</th>
                    <th>Status Actual</th>
                    <th>Acțiune</th>
                    <th>Data</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($comenzi as $c): ?>
                <tr style="text-align: center; border-bottom: 1px solid #ddd;">
                    <td style="padding: 10px;">#<?php echo $c['id']; ?></td>
                    <td><?php echo htmlspecialchars($c['nume_client']); ?></td>
                    <td><?php echo $c['total_plata']; ?> lei</td>
                    <td>
                        <span style="padding: 3px 8px; border-radius: 4px; background: #eee;">
                            <?php echo $c['status']; ?>
                        </span>
                    </td>
                    <td>
                        <form method="POST" style="display: flex; gap: 5px; justify-content: center;">
                            <input type="hidden" name="comanda_id" value="<?php echo $c['id']; ?>">
                            <select name="noul_status">
                                <option value="In asteptare">În așteptare</option>
                                <option value="In livrare">În livrare</option>
                                <option value="Finalizata">Finalizată</option>
                                <option value="Anulata">Anulată</option>
                            </select>
                            <button type="submit" name="update_status">OK</button>
                        </form>
                    </td>
                    <td><?php echo date("d.m.Y H:i", strtotime($c['data_comanda'])); ?></td>
                </tr>
                <?php endforeach; ?>
                
                <?php if(empty($comenzi)): ?>
                    <tr><td colspan="6" style="padding: 20px;">Nu există nicio comandă înregistrată.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </main>
</body>
</html>