<?php
require 'db.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $telefon = $_POST['telefon'];
    $judet = $_POST['judet'];
    $oras = $_POST['oras'];
    $adresa = $_POST['adresa'];
    $total = $_POST['total_final'];

    $stmt = $pdo->prepare("INSERT INTO comenzi (user_id, nume_client, telefon, judet, oras, adresa, total_plata) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$user_id, $_SESSION['username'], $telefon, $judet, $oras, $adresa, $total]);

    // Mesaj succes și curățare coș prin JavaScript la redirect
    echo "<script>
            localStorage.removeItem('cart');
            alert('Comanda a fost înregistrată cu succes! O puteți urmări în profilul dumneavoastră.');
            window.location.href = 'profil.php';
          </script>";
}