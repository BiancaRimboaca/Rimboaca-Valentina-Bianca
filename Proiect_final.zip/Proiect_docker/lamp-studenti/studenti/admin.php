<?php
require 'db.php';
session_start();

// --- PAZNICUL DE ACCES ---
// Verificăm dacă utilizatorul este logat și dacă are rolul de 'admin'
if (!isset($_SESSION['rol']) || $_SESSION['rol'] !== 'admin') {
    // Dacă nu e admin, îl trimitem forțat la pagina de login
    header("Location: login.php");
    exit;
}

// --- STATISTICI PENTRU DASHBOARD ---
// Luăm numărul de comenzi, produse și recenzii care așteaptă aprobare
$stmtComenzi = $pdo->query("SELECT COUNT(*) FROM comenzi");
$totalComenzi = $stmtComenzi->fetchColumn();

$stmtProduse = $pdo->query("SELECT COUNT(*) FROM produse");
$totalProduse = $stmtProduse->fetchColumn();

$stmtRecenzii = $pdo->query("SELECT COUNT(*) FROM recenzii WHERE status = 'in_asteptare'");
$recenziiNoi = $stmtRecenzii->fetchColumn();
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panou Admin - Mobila Elegantă</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
</head>
<body class="layout" id="top">

    <header>
        <nav>
    <a href="index.php">Acasă</a>
    <a href="produse.php">Produse</a>
    <a href="despre.php">Despre noi</a>
    <a href="recenzii.php">Recenzii</a>
    <a href="contact.php">Contact</a>
    <a href="cos.php">Coș</a>

    <?php if(isset($_SESSION['username']) && $_SESSION['username'] === 'admin'): ?>
        <a href="admin.php" style="background: #ffcc80; color: #333; padding: 5px 10px; border-radius: 4px; font-weight: bold;">PANOU ADMIN</a>
    <?php endif; ?>

    <a href="logout.php">Logout</a>
</nav>
        <h1>Admin Panel - Mobila Elegantă</h1>
    </header>

    <nav>
        <a href="index.php">⬅ Înapoi la Site</a>
        <a href="admin.php" class="active">Dashboard</a>
        <a href="logout.php" style="color: #ff8a80;">Logout (Admin)</a>
    </nav>

    <aside>
        <h3>Meniu Administrare</h3>
        <ul style="list-style: none; padding: 0; line-height: 2.5;">
            <li><a href="admin_produse.php">📦 Gestionare Produse</a></li>
            <li><a href="admin_comenzi.php">🛒 Gestionare Comenzi</a></li>
            <li><a href="admin_mesaje.php"> Mesaje</a></li>
            <li><a href="admin_recenzii.php">⭐ Moderare Recenzii (<?php echo $recenziiNoi; ?>)</a></li>
        </ul>
    </aside>

    <main>
        <h2>Bun venit, <?php echo $_SESSION['username']; ?>!</h2>
        <p>Aici poți gestiona întreaga activitate a magazinului tău de mobilă.</p>

        <hr style="margin: 20px 0; border: 0; border-top: 1px solid #eee;">

        <div style="display: flex; gap: 20px; flex-wrap: wrap; margin-top: 20px;">
            
            <div style="flex: 1; min-width: 200px; background: #4e342e; color: white; padding: 20px; border-radius: 10px; text-align: center;">
                <h3>Total Comenzi</h3>
                <p style="font-size: 2.5rem; font-weight: bold;"><?php echo $totalComenzi; ?></p>
                <a href="admin_comenzi.php" style="color: #ffcc80; text-decoration: none; font-size: 0.9rem;">Vezi detalii →</a>
            </div>

            <div style="flex: 1; min-width: 200px; background: #3e2723; color: white; padding: 20px; border-radius: 10px; text-align: center;">
                <h3>Produse în Catalog</h3>
                <p style="font-size: 2.5rem; font-weight: bold;"><?php echo $totalProduse; ?></p>
                <a href="admin_produse.php" style="color: #ffcc80; text-decoration: none; font-size: 0.9rem;">Gestionează →</a>
            </div>

            <div style="flex: 1; min-width: 200px; background: #8d6e63; color: white; padding: 20px; border-radius: 10px; text-align: center;">
                <h3>Recenzii noi</h3>
                <p style="font-size: 2.5rem; font-weight: bold;"><?php echo $recenziiNoi; ?></p>
                <a href="admin_recenzii.php" style="color: #ffcc80; text-decoration: none; font-size: 0.9rem;">Moderează →</a>
            </div>

        </div>
    </main>

    <footer>
        <p>&copy; 2026 Mobila Elegantă | Panou Securizat</p>
    </footer>

</body>
</html>