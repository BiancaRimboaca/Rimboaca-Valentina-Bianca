<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "Log: Am început procesarea...<br>";

require 'db.php';
if (!$pdo) { die("Log: Eroare! Conexiunea la baza de date (db.php) a eșuat."); }

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    echo "Log: Datele au fost trimise prin POST.<br>";
    
    $nume = $_POST['nume'] ?? 'Anonim';
    $mesaj = $_POST['mesaj'] ?? '';
    $rating = $_POST['stele'] ?? 5;

    echo "Log: Încerc să inserez în baza de date...<br>";

    try {
        $stmt = $pdo->prepare("INSERT INTO recenzii (nume_utilizator, comentariu, rating, status) VALUES (?, ?, ?, 'in_asteptare')");
        $stmt->execute([$nume, $mesaj, $rating]);
        
        echo "<h1 style='color:green;'>SUCCES! Recenzia a fost salvată.</h1>";
        echo "<a href='recenzii.php'>Înapoi la site</a>";
    } catch (PDOException $e) {
        echo "<h1 style='color:red;'>EROARE SQL!</h1>";
        echo "Mesaj eroare: " . $e->getMessage();
    }
} else {
    echo "Log: Eroare! Datele nu au fost trimise prin butonul de submit.";
}
?>