<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Mobila Elegantă - mobilier modern din lemn masiv, canapele, mese, scaune și paturi premium.">
  <title>Mobila Elegantă - Acasă</title>
  <link rel="stylesheet" href="style.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500&family=Playfair+Display:wght@600&display=swap" rel="stylesheet">
</head>
<body class="layout" id="top">

  <!-- HEADER + MENIU -->
  <header>
    <h1>Mobila Elegantă</h1>
    <nav>
      <a href="index.php" class="active">Acasă</a>
      <a href="produse.php">Produse</a>
      <a href="despre.php">Despre noi</a>
      <a href="recenzii.php">Recenzii</a>
      <a href="contact.php">Contact</a>
    </nav>
  </header>

  <!-- ASIDE -->
  <aside>
    <h3>Promoții</h3>
    <ul>
      <li>Reduceri la dormitoare</li>
      <li>Transport gratuit peste 1000 RON</li>
      <li>Mobilier nou în stoc</li>
    </ul>
  </aside>
    
  <!-- MAIN -->
  <main class="acasa">
    <section>
      <h2>Bun venit la Mobila Elegantă</h2>
      <p>Descoperă mobilierul care transformă orice casă într-un spațiu elegant și confortabil. Produsele noastre sunt realizate din materiale de calitate superioară, cu atenție la detalii.</p>
      <img src="https://images.unsplash.com/photo-1615874959474-d609969a20ed" alt="Dormitor elegant" class="imagine-acasa">
    </section>
  </main>

  <!-- FOOTER -->
  <footer>
    <p>&copy; 2025 Mobila Elegantă. Toate drepturile rezervate.</p>
  </footer>

  <!-- BUTON SUS -->
  <a href="#top" class="to-top">⬆️ Mergi sus</a>
  <script src="script.js"></script>
  
</body>
</html>
