document.addEventListener("DOMContentLoaded", () => {

  /* ===============================
     FORMULAR – mesaj de trimitere
     =============================== */
  const forms = document.querySelectorAll("form");
  forms.forEach(form => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      alert("Mulțumim! Formularul a fost trimis cu succes.");
      form.reset();
    });
  });

  const contLink = document.getElementById("cont-link");

if (contLink) {
  if (localStorage.getItem("loggedIn") === "yes") {
    contLink.textContent = "Contul meu";
    contLink.href = "cont.html";
  } else {
    contLink.textContent = "Autentificare";
    contLink.href = "login.html";
  }
}



  /* ===============================
     BUTON "MERGI SUS"
     =============================== */
  const toTopBtn = document.querySelector(".to-top");
  if (toTopBtn) {
    toTopBtn.style.display = "none";

    window.addEventListener("scroll", () => {
      if (window.scrollY > 100) {
        toTopBtn.style.display = "block";
      } else {
        toTopBtn.style.display = "none";
      }
    });

    toTopBtn.addEventListener("click", (e) => {
      e.preventDefault();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }


  /* ===============================
     MESAJ DE BUN VENIT + OFERTA
     =============================== */
  const mesaj = document.createElement("p");
  mesaj.textContent = "Bine ai venit la Mobila Elegantă! Descoperă produsele noastre premium.";
  mesaj.style.fontSize = "1.2rem";
  mesaj.style.margin = "15px 0";
  document.querySelector("main").prepend(mesaj);

  const oferte = document.createElement("div");
  oferte.innerHTML = "<strong>Reducere 20% la toate scaunele luna aceasta!</strong>";
  oferte.style.background = "#ffcc80";
  oferte.style.padding = "10px";
  oferte.style.borderRadius = "8px";
  oferte.style.marginTop = "15px";

  const homeSection = document.querySelector(".acasa section");
  if (homeSection) {
    homeSection.appendChild(oferte);
  }


  /* ===============================
     ANIMAȚIE IMAGINE DE ACASĂ
     =============================== */
  const imagine = document.querySelector(".imagine-acasa");
  if (imagine) {
    imagine.style.transition = "transform 0.5s ease";
    imagine.addEventListener("mouseenter", () => {
      imagine.style.transform = "scale(1.05)";
    });
    imagine.addEventListener("mouseleave", () => {
      imagine.style.transform = "scale(1)";
    });
  }



  /* ===============================
     SISTEM COȘ CUMPĂRĂTURI
     =============================== */

  // Actualizare număr produse în coș
  function updateCartCount() {
    const cart = JSON.parse(localStorage.getItem("cart")) || [];
    const count = cart.reduce((acc, item) => acc + item.qty, 0);
    const cartCounter = document.getElementById("cart-count");
    if (cartCounter) cartCounter.textContent = count;
  }

  updateCartCount();

  // Butoane "Adaugă în coș"
  const addButtons = document.querySelectorAll(".add-to-cart");

  addButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      const name = btn.getAttribute("data-name");
      const price = parseInt(btn.getAttribute("data-price"));

      let cart = JSON.parse(localStorage.getItem("cart")) || [];

      // Verificăm dacă produsul e deja în coș
      const existing = cart.find(item => item.name === name);
      if (existing) {
        existing.qty++;
      } else {
        cart.push({
          name: name,
          price: price,
          qty: 1
        });
      }

      localStorage.setItem("cart", JSON.stringify(cart));
      updateCartCount();

      alert("Produs adăugat în coș!");
    });
  });

});
