<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact - Mobila Elegantă</title>
  <link rel="stylesheet" href="style.css">
</head>
<body class="layout" id="top">
  <header>
    <h1>Mobila Elegantă</h1>
    <nav>
      <a href="index.php">Acasă</a>
      <a href="produse.php">Produse</a>
      <a href="despre.php">Despre noi</a>
      <a href="contact.php" class="active">Contact</a>
    </nav>
  </header>

  <main class="contact">
    <h2>Contactează-ne</h2>
    <p><strong>Email:</strong> contact@mobilaeleganta.ro</p>
    <p><strong>Telefon:</strong> 0740 123 456</p>
    <p><strong>Adresă:</strong> Str. Lemnului nr. 10, Cluj-Napoca</p>

    <form>
      <label for="nume">Nume:</label>
      <input type="text" id="nume" name="nume" required>

      <label for="email">Email:</label>
      <input type="email" id="email" name="email" required>

      <label for="mesaj">Mesaj:</label>
      <textarea id="mesaj" name="mesaj" rows="4" required></textarea>

      <button type="submit">Trimite</button>
    </form>
  </main>

  <footer>
    <p>&copy; 2025 Mobila Elegantă. Toate drepturile rezervate.</p>
  </footer>
  <a href="#top" class="to-top">⬆️ Mergi sus</a>
  
  <script src="script.js"></script>
  
</body>
</html>
