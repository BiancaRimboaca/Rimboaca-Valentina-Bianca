<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nume = trim($_POST['nume'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $mesaj = trim($_POST['mesaj'] ?? '');
    $errors = [];

    $_SESSION['nume'] = $nume;
    $_SESSION['email'] = $email;
    $_SESSION['mesaj'] = $mesaj;

    if (empty($nume)) {
        $errors['nume'] = "Numele este obligatoriu.";
    } elseif (strlen($nume) < 3) {
        $errors['nume'] = "Numele trebuie să aibă minim 3 caractere.";
    }

    if (empty($email)) {
        $errors['email'] = "Email-ul este obligatoriu.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = "Adresa de email nu este validă.";
    }

    if (empty($mesaj)) {
        $errors['mesaj'] = "Mesajul este obligatoriu.";
    } elseif (strlen($mesaj) < 10) {
        $errors['mesaj'] = "Mesajul trebuie să aibă minim 10 caractere.";
    }

    if (count($errors) > 0) {
        $_SESSION['errors'] = $errors;
        header("Location: index.html");
        exit();
    } else {
       
        $success_message = "Vă mulțumim, **" . htmlspecialchars($nume) . "**! Mesajul dumneavoastră ('" . htmlspecialchars(substr($mesaj, 0, 50)) . "...') a fost trimis cu succes.";

        // Stocăm mesajul de succes în sesiune
        $_SESSION['success_message'] = $success_message;

        unset($_SESSION['nume']);
        unset($_SESSION['email']);
        unset($_SESSION['mesaj']);
        
        header("Location: index.html"); 
        exit();
    }
} else {
    header("Location: index.html"); 
    exit();
}
?>