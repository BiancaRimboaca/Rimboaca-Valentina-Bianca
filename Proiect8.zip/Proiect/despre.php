<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Despre noi - Mobila Elegantă</title>
  <link rel="stylesheet" href="style.css">
</head>
<body class="layout" id="top">
  <header>
    <h1>Mobila Elegantă</h1>
    <nav>
      <a href="index.php">Acasă</a>
      <a href="produse.php">Produse</a>
      <a href="despre.php" class="active">Despre noi</a>
      <a href="contact.php">Contact</a>
    </nav>
  </header>

  <main class="despre">
    <h2>Despre noi</h2>
    <p>Suntem o echipă pasionată de design interior și de prelucrarea lemnului. Cu peste 10 ani de experiență, creăm mobilier care îmbină eleganța, confortul și durabilitatea.</p>
    <p>Fiecare piesă este realizată manual, din materiale naturale, atent selecționate, pentru a aduce un plus de stil oricărei locuințe.</p>
  </main>

  <footer>
    <p>&copy; 2025 Mobila Elegantă. Toate drepturile rezervate.</p>
  </footer>
  <a href="#top" class="to-top">⬆️ Mergi sus</a>
  <script src="script.js"></script>

</body>
</html>
