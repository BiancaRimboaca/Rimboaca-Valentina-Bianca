document.addEventListener("DOMContentLoaded", () => {

 
  const forms = document.querySelectorAll("form");
  forms.forEach(form => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      alert("Mulțumim! Formularul a fost trimis cu succes.");
      form.reset();
    });
  });


  const toTopBtn = document.querySelector(".to-top");
  if (toTopBtn) {
    toTopBtn.style.display = "none";

    window.addEventListener("scroll", () => {
      if (window.scrollY > 100) {
        toTopBtn.style.display = "block";
      } else {
        toTopBtn.style.display = "none";
      }
    });

    toTopBtn.addEventListener("click", (e) => {
      e.preventDefault();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }


  const mesaj = document.createElement("p");
  mesaj.textContent = "Bine ai venit la Mobila Elegantă! Descoperă produsele noastre premium.";
  mesaj.style.fontSize = "1.2rem";
  mesaj.style.margin = "15px 0";
  document.querySelector("main").prepend(mesaj);


  const oferte = document.createElement("div");
  oferte.innerHTML = "<strong>Reducere 20% la toate scaunele luna aceasta!</strong>";
  oferte.style.background = "#ffcc80";
  oferte.style.padding = "10px";
  oferte.style.borderRadius = "8px";
  oferte.style.marginTop = "15px";
  document.querySelector(".acasa section").appendChild(oferte);

 
  const imagine = document.querySelector(".imagine-acasa");
  if (imagine) {
    imagine.style.transition = "transform 0.5s ease";
    imagine.addEventListener("mouseenter", () => {
      imagine.style.transform = "scale(1.05)";
    });
    imagine.addEventListener("mouseleave", () => {
      imagine.style.transform = "scale(1)";
    });
  }

});