document.addEventListener("DOMContentLoaded", () => {

  const forms = document.querySelectorAll("form");
  forms.forEach(form => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      alert("Mulțumim! Formularul a fost trimis cu succes.");
      form.reset();
    });
  });


  const toTopBtn = document.querySelector(".to-top");
  if (toTopBtn) {
    toTopBtn.style.display = "none";

    window.addEventListener("scroll", () => {
      if (window.scrollY > 100) {
        toTopBtn.style.display = "block";
      } else {
        toTopBtn.style.display = "none";
      }
    });

    toTopBtn.addEventListener("click", (e) => {
      e.preventDefault();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

});
