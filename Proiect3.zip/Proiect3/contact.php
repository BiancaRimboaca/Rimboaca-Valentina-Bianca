<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="UTF-8">
  <title>Contact - Mobila Elegantă</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <h1>Mobila Elegantă</h1>
    <nav>
      <a href="index.php">Acasă</a>
      <a href="produse.php">Produse</a>
      <a href="despre.php">Despre noi</a>
      <a href="contact.php" class="active">Contact</a>
    </nav>
  </header>

  <main>
    <h2>Contactează-ne</h2>
    <p>Email: contact@mobilaeleganta.ro</p>
    <p>Telefon: 0740 123 456</p>
    <p>Adresă: Str. Lemnului nr. 10, Cluj-Napoca</p>
  </main>

  <footer>
    <p>&copy; 2025 Mobila Elegantă</p>
  </footer>
</body>
</html>
