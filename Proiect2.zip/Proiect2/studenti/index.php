<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="UTF-8">
  <title>Mobila Elegantă - Acasă</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <h1>Mobila Elegantă</h1>
    <nav>
      <a href="index.php">Acasă</a>
      <a href="produse.php">Produse</a>
      <a href="despre.php">Despre noi</a>
      <a href="contact.php">Contact</a>
    </nav>
  </header>

  <main>
    <h2>Bun venit la Mobila Elegantă</h2>
    <p>Mobilier modern, din lemn masiv, perfect pentru orice locuință.</p>
    <img src="https://images.unsplash.com/photo-1615874959474-d609969a20ed" alt="Living modern" width="600">
  </main>

  <footer>
    <p>&copy; 2025 Mobila Elegantă</p>
  </footer>
</body>
</html>
