<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="UTF-8">
  <title>Despre noi - Mobila Elegantă</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <h1>Mobila Elegantă</h1>
    <nav>
      <a href="index.php">Acasă</a>
      <a href="produse.php">Produse</a>
      <a href="despre.php" class="active">Despre noi</a>
      <a href="contact.php">Contact</a>
    </nav>
  </header>

  <main>
    <h2>Despre noi</h2>
    <p>Suntem o echipă pasionată de design interior, cu peste 10 ani de experiență în producția de mobilă din lemn masiv. Fiecare piesă este realizată manual, cu grijă pentru detalii.</p>
  </main>

  <footer>
    <p>&copy; 2025 Mobila Elegantă</p>
  </footer>
</body>
</html>
