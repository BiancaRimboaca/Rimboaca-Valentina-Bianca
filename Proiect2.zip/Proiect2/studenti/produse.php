<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="UTF-8">
  <title>Produse - Mobila Elegantă</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <h1>Mobila Elegantă</h1>
    <nav>
      <a href="index.php">Acasă</a>
      <a href="produse.php" class="active">Produse</a>
      <a href="despre.php">Despre noi</a>
      <a href="contact.php">Contact</a>
    </nav>
  </header>

  <main>
    <h2>Catalogul nostru de mobilă</h2>
    <div class="grid">
      <div class="produs">
        <img src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c" alt="Canapea" width="250">
        <p>Canapea modernă - 2500 lei</p>
      </div>
      <div class="produs">
        <img src="https://images.unsplash.com/photo-1602526218565-9e3e6c4e7d19" alt="Masa de dining" width="250">
        <p>Masă de dining - 1800 lei</p>
      </div>
      <div class="produs">
        <img src="https://images.unsplash.com/photo-1598300056393-4eab7e4b25ba" alt="Scaun" width="250">
        <p>Scaun din stejar - 350 lei</p>
      </div>
    </div>
  </main>

  <footer>
    <p>&copy; 2025 Mobila Elegantă</p>
  </footer>
</body>
</html>
