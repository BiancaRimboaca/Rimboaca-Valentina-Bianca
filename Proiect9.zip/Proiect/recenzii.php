<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Recenzii - Mobila Elegantă</title>
  <meta name="description" content="Recenziile clienților Mobila Elegantă. Experiențe reale cu mobilierul nostru din lemn masiv.">
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <h1>Mobila Elegantă</h1>
    <nav>
      <a href="index.php">Acasă</a>
      <a href="produse.php">Produse</a>
      <a href="despre.php">Despre noi</a>
      <a href="recenzii.php" class="active">Recenzii</a>
      <a href="contact.php">Contact</a>
    </nav>
  </header>

  <main class="recenzii">
    <h2>Recenziile clienților noștri</h2>
    <p class="intro">Află ce spun clienții despre Mobila Elegantă și experiența lor cu produsele noastre.</p>

    <div class="recenzii-grid">
      <article class="recenzie">
        <p>"Canapeaua cumpărată este superbă, exact ca în poze! Recomand cu drag această firmă."</p>
        <h4>— Ana P.</h4>
        <div class="stele">★★★★★</div>
      </article>

      <article class="recenzie">
        <p>"Livrare rapidă și ambalare impecabilă. Scaunele sunt de o calitate excepțională!"</p>
        <h4>— Mihai L.</h4>
        <div class="stele">★★★★★</div>
      </article>

      <article class="recenzie">
        <p>"Patul tapițat este foarte confortabil și ușor de montat. O experiență plăcută."</p>
        <h4>— Elena G.</h4>
        <div class="stele">★★★★☆</div>
      </article>

      <article class="recenzie">
        <p>"Design elegant, prețuri corecte și personal amabil. Cu siguranță voi comanda din nou."</p>
        <h4>— Radu S.</h4>
        <div class="stele">★★★★★</div>
      </article>
    </div>

    <section class="adauga-recenzie">
      <h3>Lasă și tu o recenzie</h3>
      <form>
        <label for="nume">Nume:</label>
        <input type="text" id="nume" name="nume" required>

        <label for="mesaj">Recenzia ta:</label>
        <textarea id="mesaj" name="mesaj" rows="4" required></textarea>

        <label for="stele">Alege ratingul:</label>
        <select id="stele" name="stele" required>
          <option value="5">★★★★★ (5 stele)</option>
          <option value="4">★★★★☆ (4 stele)</option>
          <option value="3">★★★☆☆ (3 stele)</option>
          <option value="2">★★☆☆☆ (2 stele)</option>
          <option value="1">★☆☆☆☆ (1 stea)</option>
        </select>

        <button type="submit">Trimite recenzia</button>
      </form>
    </section>
  </main>

  <footer>
    <p>&copy; 2025 Mobila Elegantă. Toate drepturile rezervate.</p>
  </footer>
</body>
</html>
