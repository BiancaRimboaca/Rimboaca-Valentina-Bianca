<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Mobila Elegantă - mobilier modern din lemn masiv, canapele, mese, scaune și paturi premium.">
  <title>Mobila Elegantă - Acasă</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <h1>Mobila Elegantă</h1>
    <nav>
      <a href="index.html" class="active">Acasă</a>
      <a href="produse.html">Produse</a>
      <a href="despre.html">Despre noi</a>
      <a href="recenzii.html">Recenzii</a>
      <a href="contact.html">Contact</a>
    </nav>
  </header>

  <main class="acasa">
    <section>
      <h2>Bun venit la Mobila Elegantă</h2>
      <p>Descoperă mobilierul care transformă orice casă într-un spațiu elegant și confortabil. Produsele noastre sunt realizate din materiale de calitate superioară, cu atenție la detalii.</p>
      <img src="https://images.unsplash.com/photo-1615874959474-d609969a20ed" alt="Living modern" class="imagine-acasa">
    </section>
  </main>

  <footer>
    <p>&copy; 2025 Mobila Elegantă. Toate drepturile rezervate.</p>
  </footer>
</body>
</html>
