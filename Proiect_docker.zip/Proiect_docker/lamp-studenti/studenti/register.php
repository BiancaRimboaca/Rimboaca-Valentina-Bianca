<?php
require 'db.php';
session_start();

$mesaj = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if (!empty($username) && !empty($password)) {
        // Verificăm dacă userul există deja
        $stmt = $pdo->prepare("SELECT id FROM utilizatori WHERE username = ?");
        $stmt->execute([$username]);
        
        if ($stmt->rowCount() > 0) {
            $mesaj = "Acest nume de utilizator există deja!";
        } else {
            // Criptăm parola și salvăm userul
            $parola_hash = password_hash($password, PASSWORD_DEFAULT);
            $sql = "INSERT INTO utilizatori (username, password) VALUES (?, ?)";
            $stmt = $pdo->prepare($sql);
            
            if ($stmt->execute([$username, $parola_hash])) {
                header("Location: login.php"); // Redirecționare către login
                exit;
            } else {
                $mesaj = "Eroare la înregistrare.";
            }
        }
    } else {
        $mesaj = "Toate câmpurile sunt obligatorii!";
    }
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="UTF-8">
  <title>Înregistrare</title>
  <link rel="stylesheet" href="style.css">
</head>
<body class="layout">
  <header>
      <h1>Mobila Elegantă</h1>
      <nav>
        <a href="index.html">Acasă</a>
        <a href="login.php">Autentificare</a>
      </nav>
  </header>

  <main style="max-width:400px; margin:auto; padding-top:50px;">
    <h2>Creează un cont</h2>
    <?php if($mesaj): ?>
        <p style="color:red;"><?php echo $mesaj; ?></p>
    <?php endif; ?>

    <form method="POST" action="register.php">
        <input type="text" name="username" placeholder="Alege un nume" class="input-login" required><br><br>
        <input type="password" name="password" placeholder="Alege o parolă" class="input-login" required><br><br>
        <button type="submit" class="adauga-cos">Creează cont</button>
    </form>
  </main>
</body>
</html>