<?php
session_start();
?>
<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="Mobila Elegantă - mobilier modern din lemn masiv.">
  <title>Mobila Elegantă - Acasă</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <header>
    <h1>Mobila Elegantă</h1>
    <nav>
      <a href="index.php" class="active">Acasă</a>
      <a href="produse.php">Produse</a> <a href="despre.php">Despre noi</a>
      <a href="recenzii.php">Recenzii</a>
      <a href="contact.php">Contact</a>

      <a href="cos.php">Coș(<span id="cart-count">0</span>)</a>

      <?php if(isset($_SESSION['user_id'])): ?>
          <a href="#" style="color: #ffcc80;">Salut, <?php echo htmlspecialchars($_SESSION['username']); ?>!</a>
          <a href="logout.php">Logout</a>
      <?php else: ?>
          <a href="login.php">Login</a>
      <?php endif; ?>
    </nav>
  </header>

  <main class="acasa">
    <section>
      <h2>Bun venit la Mobila Elegantă</h2>
      <p>Descoperă mobilierul care transformă orice casă într-un spațiu elegant și confortabil.</p>
      <img src="imagine-dormitor.webp" alt="Living modern" class="imagine-acasa">
    </section>
  </main>

  <footer>
    <p>&copy; 2025 Mobila Elegantă. Toate drepturile rezervate.</p>
  </footer>
  
  <a href="#top" class="to-top">⬆️ Mergi sus</a>
  <script src="script.js"></script>

</body>
</html>