<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="UTF-8">
  <title>Coșul tău</title>
  <link rel="stylesheet" href="style.css">
</head>
<body class="layout">

<header>
    <h1>Mobila Elegantă</h1>
    <nav>
      <a href="index.php">Acasă</a>
      <a href="produse.php">Produse</a>
      <a href="cos.php" class="active">Coș(<span id="cart-count">0</span>)</a>
      
      <a href="#">Salut, <?php echo htmlspecialchars($_SESSION['username']); ?>!</a>
      <a href="logout.php">Logout</a>
    </nav>
</header>

<main style="max-width:800px; margin:auto; padding:50px 20px;">
  <h1>Coșul de cumpărături</h1>

  <div id="cart-items"></div>
  <p style="font-size: 1.2rem; margin-top: 20px;"><strong>Total:</strong> <span id="cart-total">0</span> lei</p>

  <button class="adauga-cos" onclick="clearCart()">Golește coșul</button>
  <button class="adauga-cos" style="background:#2e7d32;" onclick="alert('Comanda a fost plasată!')">Trimite Comanda</button>
</main>

<script>
  // Scriptul pentru afișarea produselor din LocalStorage
  function loadCart() {
    const cart = JSON.parse(localStorage.getItem("cart")) || [];
    const container = document.getElementById("cart-items");
    let total = 0;

    container.innerHTML = "";

    if (cart.length === 0) {
        container.innerHTML = "<p>Coșul este gol.</p>";
    }

    cart.forEach(item => {
      container.innerHTML += `
        <div style="border-bottom:1px solid #ccc; padding:10px; display:flex; justify-content:space-between;">
            <span>${item.name} (x${item.qty})</span>
            <span>${item.price * item.qty} lei</span>
        </div>`;
      total += item.price * item.qty;
    });

    document.getElementById("cart-total").innerText = total;
  }

  function clearCart() {
    localStorage.removeItem("cart");
    loadCart();
    if(typeof updateCartCount === "function") updateCartCount();
    location.reload(); 
  }

  loadCart();
</script>
<script src="script.js"></script>

</body>
</html>