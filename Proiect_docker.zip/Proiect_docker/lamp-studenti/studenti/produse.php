<?php
require 'db.php';
session_start();

// Preluăm produsele din baza de date
$stmt = $pdo->query("SELECT * FROM produse");
$produse = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="UTF-8">
  <title>Produse - Mobila Elegantă</title>
  <link rel="stylesheet" href="style.css">
</head>
<body class="layout" id="top">

  <header>
    <h1>Mobila Elegantă</h1>
    <nav>
      <a href="index.html">Acasă</a>
      <a href="produse.php" class="active">Produse</a>
      <a href="contact.html">Contact</a>
      
      <?php if(isset($_SESSION['username'])): ?>
          <a href="#">Salut, <?php echo htmlspecialchars($_SESSION['username']); ?>!</a>
          <a href="logout.php">Logout</a>
      <?php else: ?>
          <a href="login.php">Login</a>
      <?php endif; ?>
    </nav>
  </header>

  <main>
    <h2>Catalogul nostru</h2>
    
    <section>
      <div class="produse-grid"> <?php foreach ($produse as $produs): ?>
            <div class="produs">
              <img src="<?php echo htmlspecialchars($produs['imagine']); ?>" 
                   alt="<?php echo htmlspecialchars($produs['nume']); ?>">
              
              <h3><?php echo htmlspecialchars($produs['nume']); ?></h3>
              <p>Preț: <?php echo $produs['pret']; ?> lei</p>
              
              <button class="adauga-cos" 
                      data-id="<?php echo $produs['id']; ?>"
                      data-name="<?php echo htmlspecialchars($produs['nume']); ?>" 
                      data-price="<?php echo $produs['pret']; ?>">
                  Adaugă în coș
              </button>
            </div>
        <?php endforeach; ?>
      </div>
    </section>
  </main>

  <footer>
    <p>&copy; 2025 Mobila Elegantă. Toate drepturile rezervate.</p>
  </footer>
</body>
</html>