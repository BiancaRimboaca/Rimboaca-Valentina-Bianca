<?php
session_start();
?>
<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact - Mobila Elegantă</title>
  <link rel="stylesheet" href="style.css">
</head>

<body class="layout" id="top">
  <header>
    <h1>Mobila Elegantă</h1>
    <nav>
      <a href="index.php">Acasă</a>
      <a href="produse.php">Produse</a>
      <a href="despre.php">Despre noi</a>
      <a href="recenzii.php">Recenzii</a>
      <a href="contact.php" class="active">Contact</a>

      <a href="cos.php">Coș(<span id="cart-count">0</span>)</a>
      
      <?php if(isset($_SESSION['user_id'])): ?>
          <a href="#" style="color: #ffcc80;">Salut, <?php echo htmlspecialchars($_SESSION['username']); ?>!</a>
          <a href="logout.php">Logout</a>
      <?php else: ?>
          <a href="login.php">Login</a>
      <?php endif; ?>
    </nav>
  </header>

  <main class="contact">
    <h2>Contactează-ne</h2>
    <p><strong>Email:</strong> contact@mobiladelux.ro</p>
    <p><strong>Telefon:</strong> 0770 403 317</p>
    <p><strong>Adresă:</strong> Str. Dunării nr. 111, Roșiori de Vede</p>

    <section class="program">
      <h3>Program de lucru</h3>
      <ul>
        <li>Luni - Vineri: 09:00 - 18:00</li>
        <li>Sâmbătă: 10:00 - 14:00</li>
        <li>Duminică: Închis</li>
      </ul>
    </section>

    <section class="harta">
      <h3>Locația noastră</h3>
      <iframe src="https://maps.google.com/maps?q=Rosiori%20de%20Vede&t=&z=13&ie=UTF8&iwloc=&output=embed" width="100%" height="300" style="border:0;" allowfullscreen loading="lazy"></iframe>
    </section>

    <section class="informatii-suplimentare">
      <h3>De ce să ne contactezi?</h3>
      <p>Suntem dedicați în a oferi mobilă de cea mai bună calitate, realizată cu atenție și profesionalism. Dacă ai întrebări, dorințe speciale sau proiecte personalizate, suntem bucuroși să te ajutăm!</p>
      <ul>
        <li>Consultanță gratuită în alegerea mobilierului potrivit</li>
        <li>Oferte personalizate</li>
        <li>Transport și montaj în toată țara</li>
      </ul>
    </section>

    <form class="formular-contact">
      <h3>Trimite-ne un mesaj</h3>
      <label for="nume">Nume:</label>
      <input type="text" id="nume" name="nume" required>

      <label for="email">Email:</label>
      <input type="email" id="email" name="email" required>

      <label for="telefon">Telefon:</label>
      <input type="tel" id="telefon" name="telefon" placeholder="Ex: 07xx xxx xxx">

      <label for="subiect">Subiect:</label>
      <input type="text" id="subiect" name="subiect" required>

      <label for="mesaj">Mesaj:</label>
      <textarea id="mesaj" name="mesaj" rows="5" required></textarea>

      <button type="submit">Trimite</button>
    </form>
  </main>

  <footer>
    <p>© 2025 Mobila Elegantă. Toate drepturile rezervate.</p>
  </footer>

  <a href="#top" class="to-top">⬆️ Mergi sus</a>

  <script src="script.js"></script>
</body>
</html>