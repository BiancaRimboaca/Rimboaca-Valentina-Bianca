<?php
require 'db.php';
session_start();

$mesaj = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    $stmt = $pdo->prepare("SELECT id, username, password FROM utilizatori WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        // Login reușit -> Salvăm în sesiune
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        header("Location: produse.php");
        exit;
    } else {
        $mesaj = "Nume sau parolă incorectă!";
    }
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="UTF-8">
  <title>Login</title>
  <link rel="stylesheet" href="style.css">
</head>
<body class="layout">
  <header>
      <h1>Mobila Elegantă</h1>
      <nav>
        <a href="index.html">Acasă</a>
        <a href="register.php">Înregistrare</a>
      </nav>
  </header>

  <main style="max-width:400px; margin:auto; padding-top:50px;">
    <h2>Autentificare</h2>
    <?php if($mesaj): ?>
        <p style="color:red;"><?php echo $mesaj; ?></p>
    <?php endif; ?>

    <form method="POST" action="login.php">
        <input type="text" name="username" placeholder="Nume utilizator" class="input-login" required><br><br>
        <input type="password" name="password" placeholder="Parolă" class="input-login" required><br><br>
        <button type="submit" class="adauga-cos">Intră în cont</button>
    </form>
  </main>
</body>
</html>