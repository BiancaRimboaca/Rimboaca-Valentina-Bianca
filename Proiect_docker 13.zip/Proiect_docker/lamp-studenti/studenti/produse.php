<?php
require 'db.php';
session_start();

// Filtrarea produselor
$cat = $_GET['categorie'] ?? 'Toate';
$stmt = ($cat == 'Toate') ? $pdo->query("SELECT * FROM produse") : $pdo->prepare("SELECT * FROM produse WHERE categorie = ?");
if($cat != 'Toate') $stmt->execute([$cat]);
$produse = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produse - Mobila Elegantă</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
</head>
<body class="layout" id="top">

    <header><h1>Mobila Elegantă</h1></header>

    <nav>
        <a href="index.php">Acasă</a>
        <a href="produse.php" class="active">Produse</a>
        <a href="despre.php">Despre noi</a>
        <a href="recenzii.php">Recenzii</a>
        <a href="contact.php">Contact</a>
        <a href="cos.php">Coș(<span id="cart-count">0</span>)</a>
        <?php if(isset($_SESSION['username'])): ?>
            <a href="profil.php" style="color:#ffcc80;">Salut, <?php echo htmlspecialchars($_SESSION['username']); ?>!</a>
            <a href="logout.php">Logout</a>
        <?php endif; ?>
    </nav>

    <aside>
        <h3>Categorii</h3>
        <ul style="list-style:none; padding:0; line-height:2;">
            <li><a href="produse.php?categorie=Toate">Toate produsele</a></li>
            <li><a href="produse.php?categorie=Living">Living</a></li>
            <li><a href="produse.php?categorie=Dormitor">Dormitor</a></li>
            <li><a href="produse.php?categorie=Bucatarie">Bucătărie</a></li>
        </ul>
    </aside>

    <main>
        <h2>Catalog: <?php echo htmlspecialchars($cat); ?></h2>
        <div class="produse-grid">
            <?php foreach ($produse as $p): ?>
                <div class="produs">
                    <img src="imagine/<?php echo $p['imagine']; ?>" alt="<?php echo htmlspecialchars($p['nume']); ?>">
                    
                    <h3><?php echo htmlspecialchars($p['nume']); ?></h3>
                    <p>Preț: <strong><?php echo $p['pret']; ?> lei</strong></p>
                    
                    <button class="adauga-cos" 
                            data-id="<?php echo $p['id']; ?>" 
                            data-name="<?php echo htmlspecialchars($p['nume']); ?>" 
                            data-price="<?php echo $p['pret']; ?>">
                        Adaugă în coș
                    </button>
                </div>
            <?php endforeach; ?>
        </div>
    </main>

    <footer><p>&copy; 2026 Mobila Elegantă</p></footer>

    <a href="#top" class="to-top" id="backToTop">⬆️</a>
    <script src="script.js?v=<?php echo time(); ?>"></script>
</body>
</html>