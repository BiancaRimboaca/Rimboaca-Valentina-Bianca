<?php
require 'db.php';
session_start();

// Verificăm dacă utilizatorul este logat. Dacă nu, redirect la login.
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Coșul Meu - Mobila Elegantă</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
    <style>
        /* Stiluri rapide pentru butoanele de cantitate */
        .btn-qty {
            background: #4e342e;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
            font-weight: bold;
            border-radius: 4px;
        }
        .btn-qty:hover { background: #8d6e63; }
        .cart-row {
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            border-bottom: 1px solid #ddd; 
            padding: 15px 0;
        }
    </style>
</head>
<body class="layout" id="top">

    <header>
        <h1>Mobila Elegantă</h1>
    </header>

    <nav>
        <a href="index.php">Acasă</a>
        <a href="produse.php">Produse</a>
        <a href="cos.php" class="active">Coș(<span id="cart-count">0</span>)</a>
        <a href="profil.php">Salut, <?php echo htmlspecialchars($_SESSION['username']); ?>!</a>
        <a href="logout.php">Logout</a>
    </nav>

    <aside>
        <h3>Politica de Livrare</h3>
        <p>Livrare <strong>GRATUITĂ</strong> la comenzi de peste 2000 lei.</p>
        <p>Taxă transport: 50 lei (pentru comenzi sub 2000 lei).</p>
        <hr style="margin: 15px 0;">
        <p>Plată: <strong>Cash la livrare</strong></p>
    </aside>

    <main>
        <h2>Produsele tale</h2>
        
        <div id="cart-items" style="margin-bottom: 2rem;"></div>

        <div id="checkout-form-container" style="display:none; background: #f9f9f9; padding: 2rem; border-radius: 10px;">
            <h3>Detalii pentru Livrare</h3>
            <form action="proceseaza_comanda.php" method="POST" id="form-comanda">
                <div style="display: flex; flex-direction: column; gap: 10px;">
                    <input type="text" name="telefon" placeholder="Număr Telefon" required style="padding:10px;">
                    <input type="text" name="judet" placeholder="Județ" required style="padding:10px;">
                    <input type="text" name="oras" placeholder="Oraș" required style="padding:10px;">
                    <textarea name="adresa" placeholder="Adresa completă (Strada, Nr, Bloc...)" required style="padding:10px;"></textarea>
                    
                    <input type="hidden" name="total_final" id="input-total-final">
                    
                    <button type="submit" class="adauga-cos" style="background:#2e7d32; margin-top:10px; cursor:pointer;">
                        Finalizează Comanda (Cash)
                    </button>
                </div>
            </form>
        </div>
    </main>

    <footer>
        <p>&copy; 2026 Mobila Elegantă. Toate drepturile rezervate.</p>
    </footer>

    <a href="#top" class="to-top" id="backToTop">⬆️ Top</a>

    <script>
        // Funcția principală care randează coșul
        function loadCart() {
            const cart = JSON.parse(localStorage.getItem("cart")) || [];
            const container = document.getElementById("cart-items");
            const formContainer = document.getElementById("checkout-form-container");
            let subtotal = 0;

            container.innerHTML = "";

            // Dacă coșul e gol, afișăm mesaj și ascundem formularul
            if (cart.length === 0) {
                container.innerHTML = "<p style='padding:20px; background:#fff3e0;'>Coșul tău este gol.</p>";
                formContainer.style.display = "none";
                actualizeazaContorNav(0);
                return;
            }

            formContainer.style.display = "block";
            
            // Construim lista de produse cu Flexbox
            // În interiorul loadCart() din cos.php
        cart.forEach((item, index) => {
    // Luăm prețul din orice câmp disponibil
            let pretProdus = parseFloat(item.price || item.pret || 0);
            let numeProdus = item.name || item.nume || "Produs";
            let cantitate = parseInt(item.qty) || 0;

        if (cantitate > 0) {
            container.innerHTML += `
                <div class="cart-row" style="display:flex; justify-content:space-between; align-items:center; padding:10px; border-bottom:1px solid #ddd;">
                    <span>${numeProdus}</span>
                    <div style="display:flex; gap:10px; align-items:center;">
                        <button onclick="schimbaCantitate('${item.id}', -1)" class="btn-qty">-</button>
                        <span>${cantitate}</span>
                        <button onclick="schimbaCantitate('${item.id}', 1)" class="btn-qty">+</button>
                    </div>
                    <span>${(pretProdus * cantitate).toFixed(2)} lei</span>
                </div>`;
            subtotal += pretProdus * cantitate;
        }
        });

            // Calcul transport
            let transport = subtotal >= 2000 ? 0 : 50;
            let totalGeneral = subtotal + transport;

            container.innerHTML += `
                <div style="margin-top:20px; text-align:right;">
                    <p>Subtotal: ${subtotal.toFixed(2)} lei</p>
                    <p>Transport: ${transport === 0 ? "GRATIS" : transport + " lei"}</p>
                    <p style="font-size: 1.4rem; color: #4e342e;"><strong>Total: ${totalGeneral.toFixed(2)} lei</strong></p>
                </div>`;
            
            // Salvăm totalul în input-ul ascuns pentru PHP
            document.getElementById("input-total-final").value = totalGeneral.toFixed(2);
            
            // Actualizăm numărul din meniul de sus
            actualizeazaContorNav(cart.reduce((sum, i) => sum + parseInt(i.qty), 0));
        }

        // Funcția pentru butoanele de + și -
        function schimbaCantitate(id, delta) {
            let cart = JSON.parse(localStorage.getItem("cart")) || [];
            const index = cart.findIndex(i => i.id == id);

            if (index !== -1) {
                cart[index].qty = parseInt(cart[index].qty) + delta;

                // Dacă ajunge la 0, ștergem produsul
                if (cart[index].qty <= 0) {
                    cart.splice(index, 1);
                }

                localStorage.setItem("cart", JSON.stringify(cart));
                loadCart();
            }
        }

        function actualizeazaContorNav(numar) {
            const el = document.getElementById("cart-count");
            if (el) el.innerText = numar;
        }

        document.addEventListener("DOMContentLoaded", loadCart);
    </script>

    <script src="script.js?v=<?php echo time(); ?>"></script>
</body>
</html>