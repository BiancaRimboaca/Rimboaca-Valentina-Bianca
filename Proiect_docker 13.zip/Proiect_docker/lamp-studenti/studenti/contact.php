<?php
session_start();
// Nu uita să ai fișierul db.php în același folder pentru conexiunea la baza de date
?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact - Mobila Elegantă</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
</head>

<body class="layout" id="top"> <header>
        <h1>Mobila Elegantă</h1>
    </header>

    <nav>
        <a href="index.php">Acasă</a>
        <a href="produse.php">Produse</a>
        <a href="despre.php">Despre noi</a>
        <a href="contact.php" class="active">Contact</a>
        <a href="cos.php">Coș(<span id="cart-count">0</span>)</a>

        <?php if(isset($_SESSION['username'])): ?>
            <a href="profil.php" style="color: #ffcc80;">Salut, <?php echo htmlspecialchars($_SESSION['username']); ?>!</a>
            <a href="logout.php">Logout</a>
        <?php else: ?>
            <a href="login.php">Login</a>
        <?php endif; ?>
    </nav>

    <aside>
        <h3>Informații Contact</h3>
        <p>📍 <strong>Adresă:</strong> Str. Dunării nr. 111, Roșiori de Vede</p>
        <p>📞 <strong>Telefon:</strong> 0770 403 317</p>
        <p>📧 <strong>Email:</strong> contact@mobiladelux.ro</p>
        
        <hr style="margin: 20px 0; border: 0; border-top: 1px solid #d7ccc8;">
        
        <h3>Program Showroom</h3>
        <ul style="list-style: none; padding: 0;">
            <li>Luni - Vineri: 09:00 - 18:00</li>
            <li>Sâmbătă: 10:00 - 14:00</li>
            <li>Duminică: Închis</li>
        </ul>
    </aside>

    <main>
        <h2>Trimite-ne un mesaj</h2>
        <p>Dacă ai întrebări despre produsele noastre sau dorești o comandă personalizată, completează formularul de mai jos.</p>

        <div class="contact-flex-wrapper">
            
            <section class="contact-column">
                <form class="formular-contact" action="proceseaza_contact.php" method="POST">
                    <div class="form-group">
                        <label for="nume">Nume Complet:</label>
                        <input type="text" id="nume" name="nume" required placeholder="Ex: Popescu Ion">

                        <label for="email">Adresă Email:</label>
                        <input type="email" id="email" name="email" required placeholder="exemplu@mail.com">

                        <label for="telefon">Telefon (opțional):</label>
                        <input type="tel" id="telefon" name="telefon" placeholder="07xxxxxxxx">

                        <label for="subiect">Subiect:</label>
                        <input type="text" id="subiect" name="subiect" required placeholder="Despre ce este vorba?">

                        <label for="mesaj">Mesajul tău:</label>
                        <textarea id="mesaj" name="mesaj" rows="5" required placeholder="Scrie aici întrebarea ta..."></textarea>

                        <button type="submit" class="btn-trimite">Trimite Mesajul</button>
                    </div>
                </form>
            </section>

            <section class="contact-column">
                <h3>Locația Noastră</h3>
                <div class="map-wrapper">
                    <iframe 
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2871.23456789!2d24.987654321!3d44.123456789!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zNDTCsDA3JzM0LjQiTiAyNMKwNTknMTUuNiJF!5e0!3m2!1sro!2sro!4v1625000000000!5m2!1sro!2sro" 
                        width="100%" 
                        height="350" 
                        style="border:0;" 
                        allowfullscreen="" 
                        loading="lazy">
                    </iframe>
                </div>
                <p style="margin-top: 1rem; font-style: italic; font-size: 0.9rem;">
                    * Ne găsești în centrul orașului Roșiori de Vede, vis-a-vis de parc.
                </p>
            </section>
        </div>
    </main>

    <footer>
        <p>&copy; 2026 Mobila Elegantă. Toate drepturile rezervate.</p>
    </footer>

    <a href="#top" class="to-top" id="backToTop">⬆️</a>

    <script src="script.js?v=<?php echo time(); ?>"></script>
</body>
</html>