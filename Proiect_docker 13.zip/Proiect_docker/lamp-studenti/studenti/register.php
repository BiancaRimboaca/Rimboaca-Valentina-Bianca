<?php
require 'db.php';
session_start();

$mesaj = "";
$eroare = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    // Criptăm parola înainte de a o salva
    $password = password_hash(trim($_POST['password']), PASSWORD_DEFAULT);

    try {
        // MODIFICARE: Folosim 'password' în loc de 'parola'
        $stmt = $pdo->prepare("INSERT INTO utilizatori (username, email, password) VALUES (?, ?, ?)");
        
        if ($stmt->execute([$username, $email, $password])) {
            $mesaj = "Cont creat cu succes! Te poți loga.";
            $eroare = false;
        }
    } catch (PDOException $e) {
        // Dacă apare eroarea 23000, înseamnă că username-ul sau email-ul există deja
        $mesaj = "Eroare: Numele de utilizator sau emailul este deja folosit.";
        $eroare = true;
    }
}
?>
<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Înregistrare - Mobila Elegantă</title>
  <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
</head>
<body class="layout">
  <header><h1>Mobila Elegantă</h1></header>
  
  <nav>
      <a href="index.php">Acasă</a>
      <a href="login.php">Login</a>
  </nav>

  <aside>
      <h3>Cont Nou</h3>
      <p>Creează un cont pentru a putea plasa comenzi și pentru a vedea istoricul cumpărăturilor tale.</p>
  </aside>

  <main>
    <div style="max-width: 400px; margin: 2rem auto; background: white; padding: 2rem; border-radius: 10px; box-shadow: 0 4px 10px rgba(0,0,0,0.1);">
        <h2>Creează Cont</h2>
        
        <?php if($mesaj): ?>
            <p style="color: white; background: <?php echo $eroare ? '#e53935' : '#43a047'; ?>; padding: 10px; border-radius: 5px; margin-top: 1rem;">
                <?php echo $mesaj; ?>
            </p>
        <?php endif; ?>

        <form method="POST" action="register.php" style="display: flex; flex-direction: column; gap: 1rem; margin-top: 1.5rem;">
            <label for="username">Nume utilizator:</label>
            <input type="text" name="username" id="username" placeholder="Alege un nume" style="padding: 12px; border: 1px solid #ddd; border-radius: 5px;" required>
            
            <label for="email">Email:</label>
            <input type="email" name="email" id="email" placeholder="adresa@email.com" style="padding: 12px; border: 1px solid #ddd; border-radius: 5px;" required>
            
            <label for="password">Parolă:</label>
            <input type="password" name="password" id="password" placeholder="Minim 6 caractere" style="padding: 12px; border: 1px solid #ddd; border-radius: 5px;" required>
            
            <button type="submit" class="btn-trimite" style="padding: 12px; background: #4e342e; color: white; border: none; border-radius: 5px; cursor: pointer; font-weight: bold;">
                Creează Contul
            </button>
        </form>
        
        <p style="margin-top: 1.5rem; text-align: center;">
            Ai deja cont? <a href="login.php" style="color: #4e342e; font-weight: bold;">Loghează-te aici</a>
        </p>
    </div>
  </main>

  <footer><p>&copy; 2026 Mobila Elegantă</p></footer>
</body>
</html>