<?php
require 'db.php'; // Verifică dacă în db.php ai variabila $pdo
session_start();

$mesaj = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password_introdusa = trim($_POST['password']);

    try {
        // 1. SELECTĂM 'password' (exact ca în DataGrip)
        $stmt = $pdo->prepare("SELECT id, username, password FROM utilizatori WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        // 2. VERIFICĂM DACĂ UTILIZATORUL EXISTĂ
        if ($user) {
            // 3. COMPARĂM PAROLA (folosind coloana 'password' extrasă din DB)
            if (password_verify($password_introdusa, $user['password'])) {
                
                // 4. SETĂM SESIUNEA
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                
                header("Location: produse.php");
                exit;
            } else {
                $mesaj = "Parola este incorectă!";
            }
        } else {
            $mesaj = "Utilizatorul nu a fost găsit!";
        }
    } catch (PDOException $e) {
        $mesaj = "Eroare la baza de date: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Mobila Elegantă</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
</head>
<body class="layout">
    <header>
        <h1>Mobila Elegantă</h1>
    </header>
    
    <nav>
        <a href="index.php">Acasă</a> 
        <a href="register.php">Înregistrare</a>
    </nav>

    <aside>
        <h3>Autentificare</h3>
        <p>Bine ai revenit! Loghează-te pentru a finaliza cumpărăturile.</p>
    </aside>

    <main>
        <div style="max-width: 400px; margin: 2rem auto; background: white; padding: 2rem; border-radius: 10px; box-shadow: 0 4px 10px rgba(0,0,0,0.1);">
            <h2>Intră în cont</h2>
            
            <?php if($mesaj): ?>
                <p style="color:white; background: #e53935; padding: 10px; border-radius: 5px; margin-bottom: 1rem;">
                    ⚠️ <?php echo $mesaj; ?>
                </p>
            <?php endif; ?>

            <form method="POST" action="login.php">
                <div style="display: flex; flex-direction: column; gap: 1rem;">
                    <label for="username">Utilizator:</label>
                    <input type="text" name="username" id="username" placeholder="Nume utilizator" 
                           style="padding: 12px; border: 1px solid #ddd; border-radius: 5px;" required>
                    
                    <label for="password">Parolă:</label>
                    <input type="password" name="password" id="password" placeholder="Parolă" 
                           style="padding: 12px; border: 1px solid #ddd; border-radius: 5px;" required>
                    
                    <button type="submit" class="btn-trimite" style="padding: 12px; background: #4e342e; color: white; border: none; border-radius: 5px; cursor: pointer; font-weight: bold;">
                        Intră în cont
                    </button>
                </div>
            </form>
            
            <p style="margin-top: 1.5rem; text-align: center;">
                Nu ai cont? <a href="register.php" style="color: #4e342e; font-weight: bold;">Creează unul aici</a>
            </p>
        </div>
    </main>

    <footer>
        <p>&copy; 2026 Mobila Elegantă. Toate drepturile rezervate.</p>
    </footer>
</body>
</html>