<?php
require 'db.php';
session_start();

if (isset($_GET['id'])) {
    $stmt = $pdo->prepare("SELECT * FROM produse WHERE id = ?");
    $stmt->execute([$_GET['id']]);
    $produs = $stmt->fetch();
    if (!$produs) { header("Location: produse.php"); exit; }
} else { header("Location: produse.php"); exit; }
?>
<!DOCTYPE html>
<html lang="ro">
<head>
  <meta charset="UTF-8">
  <title><?php echo htmlspecialchars($produs['nume']); ?></title>
  <link rel="stylesheet" href="style.css">
</head>
<body class="layout">
  <header>
    <h1>Mobila Elegantă</h1>
    <nav>
      <a href="index.php">Acasă</a>
      <a href="produse.php">Produse</a>
      <a href="contact.php">Contact</a>
      <a href="cos.php">Coș(<span id="cart-count">0</span>)</a>
    </nav>
  </header>
  <main style="max-width: 900px; margin: 40px auto; display: flex; gap: 40px; text-align: left;">
    <img src="<?php echo htmlspecialchars($produs['imagine']); ?>" style="width: 400px; border-radius: 12px;">
    <div>
      <h2><?php echo htmlspecialchars($produs['nume']); ?></h2>
      <p style="font-size: 1.5rem; color: #6d4c41;">Preț: <?php echo $produs['pret']; ?> lei</p>
      <p><strong>Descriere:</strong><br><?php echo nl2br(htmlspecialchars($produs['descriere'])); ?></p>
      <button class="adauga-cos" data-id="<?php echo $produs['id']; ?>" data-name="<?php echo htmlspecialchars($produs['nume']); ?>" data-price="<?php echo $produs['pret']; ?>">Adaugă în coș</button>
    </div>
  </main>
  <script src="script.js"></script>
</body>
</html>