document.addEventListener("DOMContentLoaded", () => {
    // Scroll Back to Top
    const btnTop = document.getElementById("backToTop");
    window.onscroll = () => { btnTop.style.display = (window.scrollY > 400) ? "block" : "none"; };

    // Update Cart Counter
    function updateCartCount() {
        const cart = JSON.parse(localStorage.getItem("cart")) || [];
        document.getElementById("cart-count").innerText = cart.reduce((a, b) => a + b.qty, 0);
    }
    updateCartCount();

    // Add to Cart
    document.addEventListener("click", (e) => {
        if (e.target.classList.contains("adauga-cos")) {
            let cart = JSON.parse(localStorage.getItem("cart")) || [];
            let id = e.target.dataset.id;
            let item = cart.find(i => i.id === id);
            if(item) item.qty++; else cart.push({id: id, name: e.target.dataset.name, price: e.target.dataset.price, qty: 1});
            localStorage.setItem("cart", JSON.stringify(cart));
            updateCartCount();
            alert("Produs adăugat!");
        }
    });
});