<?php
require 'db.php';
session_start();

// Dacă nu este logat, îl trimitem la login
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

// Preluăm comenzile utilizatorului din baza de date
// Folosim user_id salvat în sesiune la login
$stmt = $pdo->prepare("SELECT * FROM comenzi WHERE user_id = ? ORDER BY data_comanda DESC");
$stmt->execute([$_SESSION['user_id']]);
$comenzi = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profilul Meu - Mobila Elegantă</title>
    <link rel="stylesheet" href="style.css?v=<?php echo time(); ?>">
    <style>
        /* Stiluri specifice pentru tabelul de comenzi */
        .tabel-comenzi { width: 100%; border-collapse: collapse; margin-top: 2rem; }
        .tabel-comenzi th, .tabel-comenzi td { padding: 12px; border: 1px solid #ddd; text-align: center; }
        .tabel-comenzi th { background-color: #4e342e; color: white; }

        /* Culori pentru statusuri */
        .status-procesare { color: #d32f2f; font-weight: bold; } /* Roșu */
        .status-drum { color: #1976d2; font-weight: bold; }      /* Albastru */
        .status-livrat { color: #2e7d32; font-weight: bold; }    /* Verde */
    </style>
</head>
<body class="layout" id="top"> <header><h1>Mobila Elegantă</h1></header>
    
    <nav>
        <a href="index.php">Acasă</a>
        <a href="produse.php">Produse</a>
        <a href="cos.php">Coș</a>
        <a href="logout.php">Logout</a>
    </nav>

    <aside>
        <h3>Contul tău</h3>
        <p>Gestionați setările de profil și vizualizați stadiul livrărilor.</p>
    </aside>

    <main>
        <h2>Salut, <?php echo htmlspecialchars($_SESSION['username']); ?>!</h2>
        
        <div class="profil-info" style="display: flex; flex-direction: column; gap: 0.5rem; margin-top: 1rem;">
            <p><strong>Username:</strong> <?php echo htmlspecialchars($_SESSION['username']); ?></p>
            <p><strong>Status Cont:</strong> Client Autentificat</p>
        </div>

        <h3 style="margin-top: 3rem;">Istoric Comenzi</h3>
        <?php if (empty($comenzi)): ?>
            <p style="margin-top: 1rem; padding: 1rem; background: #fdf2f2;">Nu aveți nicio comandă înregistrată.</p>
        <?php else: ?>
            <table class="tabel-comenzi">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Data</th>
                        <th>Total</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($comenzi as $c): 
                        // Stabilim clasa CSS în funcție de status
                        $clasaStatus = "";
                        if ($c['status'] == 'In procesare') $clasaStatus = "status-procesare";
                        elseif ($c['status'] == 'Pe drum') $clasaStatus = "status-drum";
                        elseif ($c['status'] == 'Livrat') $clasaStatus = "status-livrat";
                    ?>
                        <tr>
                            <td>#<?php echo $c['id']; ?></td>
                            <td><?php echo date('d.m.Y', strtotime($c['data_comanda'])); ?></td>
                            <td><?php echo $c['total_plata']; ?> lei</td>
                            <td class="<?php echo $clasaStatus; ?>"><?php echo $c['status']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <div style="margin-top: 2rem;">
             <a href="logout.php" class="adauga-cos" style="width: fit-content; text-decoration: none; background: #3e2723;">Închide Sesiunea (Log Out)</a>
        </div>
    </main>

    <footer><p>&copy; 2026 Mobila Elegantă</p></footer>

    <a href="#top" class="to-top" id="backToTop">⬆️ Top</a>

    <script src="script.js?v=<?php echo time(); ?>"></script>
</body>
</html>