document.getElementById("btnAdauga").addEventListener("click", function () {
    
    const input = document.getElementById("inputActivitate");
    const text = input.value.trim();

    if (text !== "") {
        
        const azi = new Date();
        const zile = azi.getDate();
        const luni = [
            "Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie",
            "Iulie", "August", "Septembrie", "Octombrie", "Noiembrie", "Decembrie"
        ];
        const luna = luni[azi.getMonth()];
        const anul = azi.getFullYear();

        const li = document.createElement("li");
        li.textContent = `${text} – adăugată la: ${zile} ${luna} ${anul}`;

        document.getElementById("listaActivitati").appendChild(li);

        input.value = "";
    }
});
